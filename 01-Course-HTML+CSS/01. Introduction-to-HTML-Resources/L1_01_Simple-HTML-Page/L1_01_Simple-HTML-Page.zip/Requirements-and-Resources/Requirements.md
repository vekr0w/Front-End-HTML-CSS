﻿# 01 - Simple HTML Page
------

Submit your solutions in the [SoftUni Judge System](https://judge.softuni.bg/Contests/1136/Introduction-to-HTML-and-CSS.

## Constraints
 * Change the document **title** to *Simple HTML Page* 
 * Use **paragraph** tag for plain text and **strong** tag for bold text